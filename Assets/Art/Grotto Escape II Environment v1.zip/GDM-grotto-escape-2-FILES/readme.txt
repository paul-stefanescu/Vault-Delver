Artwork created by Luis Zuno 
ansimuz.com
@ansimuz

Contents

/PSD
Contains a working PSD file in case you want to make modifications

/PNG
Ready to use PNG format files

/GIFS
Example of the animations

Get more resources at ansimuz.com

